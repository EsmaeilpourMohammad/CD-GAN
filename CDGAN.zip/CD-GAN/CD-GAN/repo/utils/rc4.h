#ifndef RC4_H
#define RC4_H

/**
 * Implements rc4 encoding. Since you can decode rc4 by encoding it a second
 * time, it is also the decoder.
 *
 * Note that RC4 has a flaw: If the attacker knows a little of what the
 * encrypted text is, and it repeats over and over, the attacker can eventually
 * work out what the encryption key is.
 *
 */
class Rc4Encoder
{public:
    Rc4Encoder( const char* key, unsigned keylen );
    ~Rc4Encoder();

    void crypt( char* data, unsigned datalen );

private:
    unsigned char* _sbox;
};

#endif // RC4_H
