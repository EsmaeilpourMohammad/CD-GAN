#ifndef EXCEPTION_H
#define EXCEPTION_H

#include <tstring>

class Exception
{
public:
    Exception();
    Exception( const std::_tstring& str );

    std::_tstring msg;
};

#endif
