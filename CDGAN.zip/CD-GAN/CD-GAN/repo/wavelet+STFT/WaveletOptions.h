// -----------------------------------------------------------------------------
// Copyright 2008 Steve Hanov. All rights reserved.
//
// For permission to use, please contact steve.hanov@gmail.com. Permission will
// usually be granted without charge.
// -----------------------------------------------------------------------------
#ifndef WaveletOptions_H
#define WaveletOptions_H

#include "Events.h"

/**
  * Stores options.
  */
class WaveletOptions : public EventListener
{
public:
	WaveletOptions();
	~WaveletOptions();

    virtual void onEvent( unsigned event );

    bool autoEnhance;
    bool release; 
private:	
};

extern WaveletOptions* _options;

#endif // WaveletOptions_H
