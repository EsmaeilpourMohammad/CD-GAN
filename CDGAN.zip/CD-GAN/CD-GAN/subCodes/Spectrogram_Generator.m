% code for producing DWT and STFT spectrogram
% you only need to change paths.
% @Mohammad

clear, clc, close all


close all
clear
clc

wname = 'morl'; % Choosing the wavelet
scales = 1:1:128; % Defining scales

Files=dir('/Users/mhdpour/Desktop/UrbanSound8K/audio/fold1/*.wav');
for k=1:length(Files)
   % load a .wav file
    FileName = Files(k).name;
    [x, fs] = audioread(fullfile('/Users/mhdpour/Desktop/UrbanSound8K/audio/fold1/',FileName));   % load an audio file for STFT
    signal = audioread(fullfile('/Users/mhdpour/Desktop/UrbanSound8K/audio/fold1/',FileName));     % load an audio file for DWT
    x = x(:, 1);                        % get the first channel
    coefs = cwt(signal, scales, wname); % Get wavelet coefficients

    % define analysis parameters
    xlen = length(x);                   % length of the signal
    wlen = 1024;                        % window length (recomended to be power of 2)
    hop = wlen/4;                       % hop size (recomended to be power of 2)
    nfft = 4096;                        % number of fft points (recomended to be power of 2)

    % perform STFT
    [S, f, t] = stft(x, wlen, hop, nfft, fs);

    % define the coherent amplification of the window
    K = sum(hamming(wlen, 'periodic'))/wlen;

    % take the amplitude of fft(x) and scale it, so not to be a
    % function of the length of the window and its coherent amplification
    S = abs(S)/wlen/K;

    % correction of the DC & Nyquist component
    if rem(nfft, 2)                     % odd nfft excludes Nyquist point
        S(2:end, :) = S(2:end, :).*2;
    else                                % even nfft includes Nyquist point
        S(2:end-1, :) = S(2:end-1, :).*2;
    end

    % convert amplitude spectrum to dB (min = -120 dB)
    S = 20*log10(S + 1e-6);

    % plot the spectrogram
    figure(1)
    surf(t, f, S)
    shading interp
    %axis tight
    axis off
    box on
    view(0, 90)
    [my_filepath,My_fname,my_ext] = fileparts(FileName);
    saveas(figure(1),fullfile('/Users/mhdpour/Desktop/STFT_UrbanSound8K/audio/fold10/Spec_10/',My_fname),'png');
    
    %clear figure(1)

    [cfs,frq] = cwt(signal);
    % you can add more arguments, likr frequecny, overlapping, etc.
    tmp1 = abs(cfs);
    t1 = size(tmp1,2);
    tmp1 = tmp1';
    minv = min(tmp1);
    tmp1 = (tmp1-minv(ones(1,t1),:));
    maxv = max(tmp1);
    maxvArray = maxv(ones(1,t1),:);
    indx = maxvArray<eps;
    tmp1 = 240*(tmp1./maxvArray);
    tmp2 = 1+fix(tmp1);
    tmp2(indx) = 1;
    tmp2 = tmp2';
    t = 0:length(signal)-1;
    pcolor(t,frq,tmp2);
    shading interp
    %ylabel('Frequency')
    %title('Scalogram Scaled By Level')
    colormap(pink(240))
    % amor is Morlet wavelet
    % 'morse' is Morse wavelet
    % 'bump' is bump wavelet
    colorbar('off')
    xlabel('')
    title('')
    set(gca,'YTick',[])
    set(gca,'XTick',[])
    ylabel('')
    
    saveas(figure(1),fullfile('/Users/mhdpour/Desktop/DWT_UrbanSound8K/audio/fold10/Spec_10/',My_fname),'png');
    
    
    clear figure(1)

    %set(gca, 'FontName', 'Times New Roman', 'FontSize', 14)
    %xlabel('Time, s')
    %ylabel('Frequency, Hz')

    %title('Amplitude spectrogram of the signal')

    %handl = colorbar;
    %set(handl, 'FontName', 'Times New Roman', 'FontSize', 14)
    %ylabel(handl, 'Magnitude, dB')
end


